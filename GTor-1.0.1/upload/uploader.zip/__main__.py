#!/usr/bin/env python
# coding:utf-8

import sys
import os

BANNER = '''\
===============================================================
 Gtor server deployment process, start uploading python server
===============================================================
'''

FOOTER = '''\
Uploaded successfully, please do not forget to put your appid to  fill in  proxy.ini, thanks. Press Enter to exit the program.
'''

def main():
    import mimetypes
    mimetypes._winreg = None
    import appcfg
    dirname = os.path.dirname(os.path.abspath(__file__))
    if dirname.endswith('.zip'):
    	dirname = os.path.dirname(dirname)
    os.chdir(dirname)
    appcfg.main()

if __name__ == '__main__':
   try:
        print BANNER.decode('utf-8').encode(sys.getfilesystemencoding(), 'replace')
        main()
        print
        print FOOTER.decode('utf-8').encode(sys.getfilesystemencoding(), 'replace')
        raw_input()
   except KeyboardInterrupt:
        pass