import sys
import zipfile
import zipimport
import os

zf = zipfile.PyZipFile('uploader.zip', mode='w')
for dirpath, dirnames, filenames in os.walk('.'): 

    if dirpath:
    	print 'Directory', dirpath
    	zf.write(dirpath)
    else:
    	print "none..." 


    for filename in filenames: 
        print ' File', dirpath + filename 
        zf.write(dirpath +'\\'+ filename)

zf.close()
'''
zf = zipfile.PyZipFile('uploader.zip', mode='w')
try:
    zf.write('__main__1.py')
finally:
    zf.close()
for name in zf.namelist():
    print name 
'''
